package com.ductho.nguphaptienganh.Ads;

import com.google.android.gms.ads.InterstitialAd;

public class Common {

    public static InterstitialAd interstitialAd = null;


}
